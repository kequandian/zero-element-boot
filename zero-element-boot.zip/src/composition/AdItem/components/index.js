import TextContent from './TextContent';
import FootContent from './FootContent';

export{
    TextContent,
    FootContent,
}