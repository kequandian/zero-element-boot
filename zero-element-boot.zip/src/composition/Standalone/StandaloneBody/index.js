const React = require('react');
const AutoComponent = require('@/components/AutoComponent');

const _layout = require('./_layout');

module.exports =function StandaloneBody(props) {

  const allComponents = {
    // JarItem
  }

  const config = {
    layout: _layout,
    ...props,
  };

  // console.log('props = ', props)

  return (
    <AutoComponent {...config} allComponents={null} />
  )

}