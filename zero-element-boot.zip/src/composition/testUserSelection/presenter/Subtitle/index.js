import React from 'react';
require('./index.less')

export default function Subtitle({content}){
    return (
        <div className="subtitle">{content}</div>
    )
}