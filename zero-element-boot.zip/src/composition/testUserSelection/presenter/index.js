
import Avatar from './Avatar';
import Title from './Title';
import Seperator from './Seperator';
import ContentText from './ContentText'

export {
  Avatar,
  Title,
  Seperator,
  ContentText
}