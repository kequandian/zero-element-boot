import React from 'react';

export default function (props) {
    const { title } = props;
    return <div style={{ fontSize: '16px' }}>{title}</div>
}