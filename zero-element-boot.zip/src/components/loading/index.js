const React = require('react');

require('./index.less')

module.exports = function ({styles={}}) {
  return <div className="loading" style={styles}></div>
}