// @ts-nocheck
import { Plugin } from 'D:/workspace2015/zero/project/zero-element-boot/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','dva','getInitialState','locale','locale','request',],
});

export { plugin };
