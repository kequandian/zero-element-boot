// @ts-nocheck
import React from 'react';
import { ApplyPluginsType } from 'D:/workspace2015/zero/project/zero-element-boot/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/AddUserPage",
    "exact": true,
    "component": require('@/pages/AddUserPage/index.js').default
  },
  {
    "path": "/chakra",
    "exact": true,
    "component": require('@/pages/chakra.js').default
  },
  {
    "path": "/CheckBoxModalDemo",
    "exact": true,
    "component": require('@/pages/CheckBoxModalDemo/index.js').default
  },
  {
    "path": "/CheckboxPageDemo",
    "exact": true,
    "component": require('@/pages/CheckboxPageDemo/index.js').default
  },
  {
    "path": "/ComponentListDemo",
    "exact": true,
    "component": require('@/pages/ComponentListDemo/index.js').default
  },
  {
    "path": "/ComponentListDemo/LayoutList",
    "exact": true,
    "component": require('@/pages/ComponentListDemo/LayoutList/index.js').default
  },
  {
    "path": "/ComponentListDemo/LayoutList/ListItem",
    "exact": true,
    "component": require('@/pages/ComponentListDemo/LayoutList/ListItem.js').default
  },
  {
    "path": "/ComponentListDemo/ListItem",
    "exact": true,
    "component": require('@/pages/ComponentListDemo/ListItem/index.js').default
  },
  {
    "path": "/Demo/AdItemDemo",
    "exact": true,
    "component": require('@/pages/Demo/AdItemDemo/index.js').default
  },
  {
    "path": "/Demo/CartListDemo",
    "exact": true,
    "component": require('@/pages/Demo/CartListDemo.js').default
  },
  {
    "path": "/Demo/ImageAnimationDemo",
    "exact": true,
    "component": require('@/pages/Demo/ImageAnimationDemo.js').default
  },
  {
    "path": "/Demo/PlainListDemo",
    "exact": true,
    "component": require('@/pages/Demo/PlainListDemo.js').default
  },
  {
    "path": "/",
    "exact": true,
    "component": require('@/pages/index.js').default
  },
  {
    "path": "/PresenterTestDemo",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/BigBox",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/BigBox.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/Comment",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/Comment.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/ExampleTwo",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/ExampleTwo/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/example_one",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/example_one.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/Example_two",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/Example_two.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/FootContent",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/FootContent.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/ImageAnimation",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/ImageAnimation.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/NewDemoList",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/NewDemoList/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/NewDemoList/presenter/ImageAnimation",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/NewDemoList/presenter/ImageAnimation/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/TextContent",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/TextContent.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/TheText",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/TheText.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/NewDemo/Title",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/NewDemo/Title.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/TodoList",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/TodoList/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/TodoList/Sandbox",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/TodoList/Sandbox.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/TodoList/TodoItem/Content_text",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/TodoList/TodoItem/Content_text/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/TodoList/TodoItem",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/TodoList/TodoItem/index.js').default
  },
  {
    "path": "/PresenterTestDemo/plugins/TodoList/TodoItem/Message",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/plugins/TodoList/TodoItem/Message/index.js').default
  },
  {
    "path": "/PresenterTestDemo/Sandbox",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/Sandbox.js').default
  },
  {
    "path": "/PresenterTestDemo/TodoItem/Content_text",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/TodoItem/Content_text/index.js').default
  },
  {
    "path": "/PresenterTestDemo/TodoItem",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/TodoItem/index.js').default
  },
  {
    "path": "/PresenterTestDemo/TodoItem/Message",
    "exact": true,
    "component": require('@/pages/PresenterTestDemo/TodoItem/Message/index.js').default
  },
  {
    "path": "/RadioModalDemo",
    "exact": true,
    "component": require('@/pages/RadioModalDemo/index.js').default
  },
  {
    "path": "/SelectDemo",
    "exact": true,
    "component": require('@/pages/SelectDemo/index.js').default
  },
  {
    "path": "/SelectDemo/Sandbox",
    "exact": true,
    "component": require('@/pages/SelectDemo/Sandbox.js').default
  },
  {
    "path": "/SelectDemo/SelectRightIconItem",
    "exact": true,
    "component": require('@/pages/SelectDemo/SelectRightIconItem/index.js').default
  },
  {
    "path": "/SelectDemo/SelectUpperRightItem",
    "exact": true,
    "component": require('@/pages/SelectDemo/SelectUpperRightItem/index.js').default
  },
  {
    "path": "/TableDemo",
    "exact": true,
    "component": require('@/pages/TableDemo/index.js').default
  },
  {
    "path": "/TableDemo/Sandbox",
    "exact": true,
    "component": require('@/pages/TableDemo/Sandbox.js').default
  },
  {
    "path": "/TableDemo/TableItem",
    "routes": [
      {
        "path": "/TableDemo/TableItem",
        "exact": true,
        "component": require('@/pages/TableDemo/TableItem/index.js').default
      }
    ],
    "component": require('@/pages/TableDemo/TableItem/_layout.js').default
  },
  {
    "path": "/TestCart/TestPageCart",
    "exact": true,
    "component": require('@/pages/TestCart/TestPageCart.js').default
  },
  {
    "path": "/TestCases/ImageAnimationDemo",
    "exact": true,
    "component": require('@/pages/TestCases/ImageAnimationDemo.js').default
  },
  {
    "path": "/TestCases/IsValidElementTest",
    "exact": true,
    "component": require('@/pages/TestCases/IsValidElementTest.js').default
  },
  {
    "path": "/TestChakraUI/AirbnbExample",
    "exact": true,
    "component": require('@/pages/TestChakraUI/AirbnbExample.js').default
  },
  {
    "path": "/TestComposition/AvatarItemDemo",
    "exact": true,
    "component": require('@/pages/TestComposition/AvatarItemDemo.js').default
  },
  {
    "path": "/TestSelector/TestDefaultHoverIndicator",
    "exact": true,
    "component": require('@/pages/TestSelector/TestDefaultHoverIndicator.js').default
  },
  {
    "path": "/TestSelector/TestPageCart",
    "exact": true,
    "component": require('@/pages/TestSelector/TestPageCart.js').default
  },
  {
    "path": "/TestSelector/TestSelector",
    "exact": true,
    "component": require('@/pages/TestSelector/TestSelector.js').default
  },
  {
    "path": "/TestUserListDemo",
    "exact": true,
    "component": require('@/pages/TestUserListDemo/index.js').default
  },
  {
    "path": "/UserCheckboxDemo",
    "exact": true,
    "component": require('@/pages/UserCheckboxDemo/index.js').default
  },
  {
    "path": "/UserCheckboxDemo/Sandbox",
    "exact": true,
    "component": require('@/pages/UserCheckboxDemo/Sandbox.js').default
  },
  {
    "path": "/UserCheckboxDemo/UserInfoItem",
    "exact": true,
    "component": require('@/pages/UserCheckboxDemo/UserInfoItem/index.js').default
  },
  {
    "path": "/UserRadioDemo",
    "exact": true,
    "component": require('@/pages/UserRadioDemo/index.js').default
  },
  {
    "path": "/UserRadioDemo/Sandbox",
    "exact": true,
    "component": require('@/pages/UserRadioDemo/Sandbox.js').default
  },
  {
    "path": "/UserRadioDemo/UserInfoItem",
    "exact": true,
    "component": require('@/pages/UserRadioDemo/UserInfoItem/index.js').default
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
