import React from 'react';

export default function (props) {
  return <div>Default {JSON.stringify(props)}</div>
}