export default {
  'GET /api/userData': {
    "code": 200,
    "data": [
      {
        "id": 1,
        "name": "darren",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202110201819994.png",
      },
      {
        "id": 2,
        "name": "李",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202111031707036.jpg",
      },
      {
        "id": 3,
        "name": "Game-ww",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202110201820036.png",
      },
      {
        "id": 4,
        "name": "刘乐",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202111031707909.jpg",
      },
      {
        "id": 5,
        "name": "燃点",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202111031707772.jpg",
      }
    ],
    "message": "Success"
  }
}
