export default {
  'GET /api/selectdata': {
    "code": 200,
    "data": [
      {
        "id": 1,
        "name": "Male",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202110201819994.png",
      },
      {
        "id": 2,
        "name": "Female",
        "avatar": "https://gitee.com/hdij/this-is-a-project/raw/master///202110201820036.png",
      }
    ],
    "message": "Success"
  }
}
